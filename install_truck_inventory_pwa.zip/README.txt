INSTALL TRUCK INVENTORY — INSTALLABLE OFFLINE WEB APP

Files:
- index.html: the inventory app
- manifest.webmanifest: app name and home-screen settings
- sw.js: offline caching
- icon.svg: app icon

IMPORTANT:
A service worker and reliable home-screen installation require the files to be served from an HTTPS website (or localhost). Opening index.html directly from Downloads does NOT enable full PWA installation/offline caching.

Suggested setup:
1. Upload these four files to a static HTTPS host you control (for example, a private GitHub Pages site or another static host).
2. Open the HTTPS page in Chrome on Android.
3. Use Chrome menu > Install app (or Add to Home screen).
4. Open the installed app once while online so it can cache the app files.
5. Test offline mode and export an inventory backup regularly.

Inventory quantities are stored in browser localStorage for that installed site's origin. Clearing site data or uninstalling/resetting browser data may erase them, so use Export backup periodically. The app does not sync between devices.
